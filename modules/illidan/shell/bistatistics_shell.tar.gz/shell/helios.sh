#!/bin/bash
SPARK_HOME=/hadoopecosystem/spark
SparkMaster="spark://10.10.2.14:7077"
JarHome="/script/bi/bi_statistics/jar/BISparkStatistics.jar"
Args="--projectName helios --deleteOld true"
$SPARK_HOME/bin/spark-submit --master $SparkMaster --class "com.moretv.bi.template.BiTimedTaskStatistics" $JarHome $Args